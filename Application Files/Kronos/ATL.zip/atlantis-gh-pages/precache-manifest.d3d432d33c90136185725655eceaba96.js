self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7deaeeb2da59402659221e3b86e13f4c",
    "url": "/atlantis/index.html"
  },
  {
    "revision": "06f0673ef9b6567d70db",
    "url": "/atlantis/static/js/2.c76e2d1e.chunk.js"
  },
  {
    "revision": "5f5ca9dccbfa3236d2de99c480d68e94",
    "url": "/atlantis/static/js/2.c76e2d1e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "73db107da4fa5aa0b522",
    "url": "/atlantis/static/js/main.f71bb0e6.chunk.js"
  },
  {
    "revision": "16cf8bd06ab2bd78355d",
    "url": "/atlantis/static/js/runtime-main.14917799.js"
  },
  {
    "revision": "0c981b1ea4ee3d5012b38e76385058fe",
    "url": "/atlantis/static/media/flappyboy.gb.0c981b1e.zip"
  },
  {
    "revision": "336c4267480cf1084d2746ec6634e0d8",
    "url": "/atlantis/static/media/gameboy.336c4267.svg"
  },
  {
    "revision": "830a393c7fa03a4960697bb694c90cf6",
    "url": "/atlantis/static/media/infinity.gb.830a393c.zip"
  },
  {
    "revision": "605b7db7b8a7f0aac7a8dbeb41bb36e4",
    "url": "/atlantis/static/media/postbot.gb.605b7db7.zip"
  },
  {
    "revision": "4b4c65205ff60c5fa1f88af533ff0d1d",
    "url": "/atlantis/static/media/space-invasion.gb.4b4c6520.zip"
  }
]);